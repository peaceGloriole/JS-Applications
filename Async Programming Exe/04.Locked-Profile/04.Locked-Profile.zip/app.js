async function lockedProfile() {
    const url = `http://localhost:3030/jsonstore/advanced/profiles`;
    const main = document.querySelector(`main`);
    const button = document.querySelector(`button`);

    const request = await fetch(url);
    const data = await request.json();

    const profiles = Object.values(data);

    button.addEventListener(`click`, (e) => {
        e.preventDefault();
        profiles.forEach((profile, i) => {
            const profileDiv = document.createElement(`div`);
            profileDiv.classList.add(`profile`);
            profileDiv.innerHTML = `
                <img src="./iconProfile2.png" class="userIcon" />
                <label>Lock</label>
                <input type="radio" name="user${i + 1}Locked" value="lock" checked>
                <label>Unlock</label>
                <input type="radio" name="user${i + 1}Locked" value="unlock"><br>
                <hr>
                <label>Username</label>
                <input type="text" name="user${i + 1}Username" value="${profile.username}" disabled readonly />
                <div id="user${i + 1}HiddenFields">
                    <hr>
                    <label>Email:</label>
                    <input type="email" name="user${i + 1}Email" value="${profile.email}" disabled readonly />
                    <label>Age:</label>
                    <input type="email" name="user${i + 1}Age" value="${profile.age}" disabled readonly />
                </div>
                <button>Show more</button>
            `;
            main.appendChild(profileDiv);
            const showMoreButton = profileDiv.querySelector(`button`);
            showMoreButton.addEventListener(`click`, () => {
                const lockUnlock = profileDiv.querySelector(`input[type="radio"]:checked`).value;
                if (lockUnlock === `unlock`) {
                    const hiddenFields = profileDiv.querySelector(`div`);
                    if (showMoreButton.textContent === `Show more`) {
                        hiddenFields.style.display = `block`;
                        showMoreButton.textContent = `Hide it`;
                    } else {
                        hiddenFields.style.display = `none`;
                        showMoreButton.textContent = `Show more`;
                    }
                }
            });
        });
    });
}